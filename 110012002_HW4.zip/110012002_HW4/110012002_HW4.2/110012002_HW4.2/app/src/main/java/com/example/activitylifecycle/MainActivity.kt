package com.example.activitylifecycle

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    private var nbCount = 0
    private var text = ""
    private lateinit var count: TextView
    private lateinit var editText : EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        count = findViewById(R.id.counter)
        editText = findViewById(R.id.editText)

        increment()
        editText()

        if(savedInstanceState != null) {
            nbCount = savedInstanceState.getInt("nbCount")
            text = savedInstanceState.getString("editText").toString()
            count.text = nbCount.toString()
        }
    }

    private fun increment() {
        val btnCount = findViewById<Button>(R.id.btnCount)

        btnCount.setOnClickListener {
            nbCount++
            count.text = nbCount.toString()
        }
    }

    private fun editText() {
        editText.setOnClickListener {
            text = editText.text.toString()
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("nbCount", nbCount)
        outState.putString("editText", text)
    }
}