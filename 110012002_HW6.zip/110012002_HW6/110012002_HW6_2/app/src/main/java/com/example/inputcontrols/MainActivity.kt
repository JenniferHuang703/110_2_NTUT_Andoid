package com.example.inputcontrols

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val checkbox = findViewById<CheckBox>(R.id.checkBox)
        val checkbox2 = findViewById<CheckBox>(R.id.checkBox2)
        val checkbox3 = findViewById<CheckBox>(R.id.checkBox3)
        val checkbox4 = findViewById<CheckBox>(R.id.checkBox4)
        val checkbox5 = findViewById<CheckBox>(R.id.checkBox5)
        val button = findViewById<Button>(R.id.showToastBtn)

        button.setOnClickListener {
            val result = StringBuilder()
            result.append("Toppings: ")
            if (checkbox.isChecked) {
                result.append(" Chocolate syrup")
            }
            if (checkbox2.isChecked) {
                result.append(" Sprinkles")
            }
            if (checkbox3.isChecked) {
                result.append(" Crushed nuts")
            }
            if (checkbox4.isChecked) {
                result.append(" Cherries")
            }
            if (checkbox5.isChecked) {
                result.append(" Orio cookies crumble")
            }
            Toast.makeText(applicationContext, result.toString(), Toast.LENGTH_LONG).show()
        }
    }
}